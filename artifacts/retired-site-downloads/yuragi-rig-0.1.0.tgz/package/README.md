# @yuragi/rig

A TypeScript single-surface illustration rig extracted from the Momo character in Kirameki Catch.

## Entry points

- `@yuragi/rig`: WebGL player, pure simulation, model validation, Momo preset, TypeScript types.
- `@yuragi/rig/vue`: `YuragiCharacter` Vue 3 component.
- `@yuragi/rig/react`: `YuragiCharacter` React 18/19 component.

Vue and React are optional peer dependencies. Importing the core does not import either framework.

```ts
import { createPlayer, createMomoModel } from '@yuragi/rig'
const player = await createPlayer({
  canvas: document.querySelector<HTMLCanvasElement>('canvas')!,
  model: createMomoModel('/models/momo/texture.webp'),
})
player.wave()
player.setMotion({ hair: 1.2, sway: .8 })
player.destroy()
```

The texture is distributed separately. Place it at the URL you pass to createMomoModel.

The pure `createSimulation(model)` API allows a custom renderer to consume `mesh.positions`, `mesh.uvs`, and `mesh.indices`. Model data is serializable, validated, and cloned per simulation. The initial pose behaviors use semantic humanoid pin names from Momo; binding a new character requires configuring its own image, pins, pose regions, and local chains.

See the accompanying Vue documentation site for options, adapters, editable fields, and lifecycle behavior. This local preview package has not been published to the npm registry.
